package com.example.homeezch

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import com.example.homeezch.ai.AiPreferences
import com.example.homeezch.ai.EvaEngine
import org.junit.Test
import org.junit.Assert.*

class AiEntryDeviceTest {
    @Test fun assistantStartsCompactlyInsideHomeWithoutAccessibility() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        check(context.packageName.endsWith(".debug"))
        prepareLauncherTest()
        context.getSharedPreferences("ezch_launcher_prefs", Context.MODE_PRIVATE).edit().remove("profiles_v1").remove("active_profile").commit()
        AiPreferences.store(context).edit().clear().commit()
        AiPreferences.store(context).edit().putBoolean("tts", false).putBoolean("prefer_offline", true).commit()
        InstrumentationRegistry.getInstrumentation().uiAutomation.grantRuntimePermission(context.packageName, android.Manifest.permission.RECORD_AUDIO)
        val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        ActivityScenario.launch<MainActivity>(Intent(context, MainActivity::class.java)).use {
            val entry = device.wait(Until.findObject(By.text("◉ EVA")), 15000)
            assertNotNull("AI entry must be visible even before activation", entry)
            entry.click()
            assertTrue(device.wait(Until.hasObject(By.descContains("Ева.")), 15000))
            assertTrue(AiPreferences.enabled(context))
            assertFalse(AiPreferences.networkSpeech(context))
            assertEquals(!deviceLowRam(context), EvaEngine.handsFreeEnabled(context))
            assertEquals(context.packageName, device.currentPackageName)
            assertNotNull(device.findObject(By.text("◉ EVA")))
        }
        AiPreferences.store(context).edit().putBoolean("enabled", false).commit()
    }
}
