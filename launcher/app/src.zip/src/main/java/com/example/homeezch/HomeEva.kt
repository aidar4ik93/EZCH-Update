package com.example.homeezch

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.homeezch.ai.*
import kotlinx.coroutines.delay

/** Compact foreground fallback works without granting accessibility access. */
@Composable
internal fun HomeEva(request: Int, cardWidth: Dp, onNavigation: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val navigate by rememberUpdatedState(onNavigation)
    var resumed by remember { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    var visible by remember { mutableStateOf(false) }
    var activity by remember { mutableLongStateOf(0L) }
    var session by remember { mutableIntStateOf(0) }
    var pendingText by remember { mutableStateOf<String?>(null) }
    var pendingStart by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<VoicePanel?>(null) }
    var caption by remember { mutableStateOf("") }
    val externalPanel by EvaAppService.panelVisibility.collectAsState()
    fun open() {
        // The wake recognizer must release its microphone before the command recognizer starts.
        EvaEngine.release {
            if (resumed) {
                activity = android.os.SystemClock.elapsedRealtime()
                if (EvaAppService.current != null) EvaAppService.current?.showMiniPanel()
                else { visible = true; session++ }
            }
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingStart = true
        else android.widget.Toast.makeText(context, "Для голосовых команд разрешите микрофон в настройках EVA", android.widget.Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(request) {
        if (request > 0) {
            if (EvaEngine.hasMicPermission(context)) pendingStart = true else permission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    LaunchedEffect(resumed, pendingStart) {
        if (resumed && pendingStart) { pendingStart = false; open() }
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) resumed = true
            if (event == Lifecycle.Event.ON_PAUSE) {
                resumed = false; panel?.pause(); visible = false; pendingText = null; EvaEngine.release()
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); EvaEngine.release() }
    }
    val wakeCommand = remember {
        { text: String ->
            EvaEngine.release {
                if (resumed) {
                    activity = android.os.SystemClock.elapsedRealtime()
                    val service = EvaAppService.current
                    if (service != null) service.submitCommand(text)
                    else { pendingText = text.takeIf { it.isNotBlank() }; visible = true; session++ }
                }
            }
        }
    }
    DisposableEffect(wakeCommand) {
        EvaEngine.attach(wakeCommand) { message ->
            if (message.contains("недоступ") || message.contains("занят"))
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
        }
        onDispose { EvaEngine.detach(wakeCommand) }
    }
    LaunchedEffect(resumed, visible, request, externalPanel) {
        if (resumed && !visible && !externalPanel) {
            delay(1000)
            EvaEngine.startWake(context)
        } else EvaEngine.stop()
    }
    LaunchedEffect(visible, activity) {
        if (visible) { delay(30_000); visible = false }
    }
    if (visible) {
        Column(horizontalAlignment = Alignment.End) {
        if (caption.isNotBlank()) Text(caption, color = Color.White, fontSize = 12.sp, maxLines = 3,
            modifier = Modifier.widthIn(max = 260.dp).background(Color(0xDD0A1020)).padding(8.dp))
        AndroidView(factory = { ctx ->
            VoicePanel(ctx, homeResult = { navigate(it) }, close = { visible = false }, mini = true,
                onActivity = { activity = android.os.SystemClock.elapsedRealtime() },
                onStatusText = { caption = it }).also { panel = it }.view
        }, modifier = Modifier.width(cardWidth / 1.5f).height((94.dp * AppCardScale) / 1.5f))
        }
        LaunchedEffect(panel, session) {
            delay(250)
            val text = pendingText
            pendingText = null
            if (text != null) panel?.submit(text) else panel?.listen()
        }
        DisposableEffect(Unit) { onDispose { panel?.destroy(); panel = null } }
    }
}
