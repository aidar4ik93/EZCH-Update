package com.example.homeezch

import android.content.Context
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay

/** Device-local setup; all privileged changes require an explicit button press. */
class HomeSetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                HomeSetupPanel {
                    getSharedPreferences("home_setup", Context.MODE_PRIVATE).edit()
                        .putBoolean("setup_reviewed_v24", true).apply()
                    finish()
                }
            }
        }
    }
}

@Composable
private fun HomeSetupPanel(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var state by remember { mutableStateOf(readHomeSetup(context)) }
    var resumed by remember { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    var notice by remember { mutableStateOf("") }
    val homeRequest = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        state = readHomeSetup(context)
        notice = when {
            state.effectiveHome -> "Назначение подтверждено: Android открывает EZCH."
            state.roleMismatch -> "Роль HOME предоставлена, но прошивка продолжает открывать другой рабочий стол."
            else -> "Android не подтвердил назначение. Можно повторить выбор или открыть системный список рабочих столов."
        }
    }
    // ROLE_HOME needs a calling Activity. NEW_TASK/startActivity loses the caller,
    // and PermissionController may finish without displaying the role prompt.
    fun launchHomeRequest(intent: android.content.Intent?) {
        if (intent == null) {
            notice = "Прошивка не предоставляет штатный выбор HOME. Назначение не подтверждено."
            return
        }
        try {
            homeRequest.launch(android.content.Intent(intent).apply {
                flags = flags and android.content.Intent.FLAG_ACTIVITY_NEW_TASK.inv()
            })
        } catch (_: android.content.ActivityNotFoundException) {
            notice = "Системный выбор HOME недоступен на этой прошивке."
        } catch (_: SecurityException) {
            notice = "Прошивка запретила открытие выбора HOME. Назначение не подтверждено."
        }
    }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("home_setup", Context.MODE_PRIVATE)
        if (!state.effectiveHome && !prefs.getBoolean("home_system_prompt_v26", false)) {
            prefs.edit().putBoolean("home_system_prompt_v26", true).apply()
            launchHomeRequest(HomeRole.requestIntent(context))
        }
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                state = readHomeSetup(context)
                resumed = true
            } else if (event == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    // A service may connect just after Settings returns. Poll only while this screen is visible.
    LaunchedEffect(resumed) {
        if (resumed) while (true) {
            state = readHomeSetup(context)
            delay(1000)
        }
    }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.padding(28.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Настройка EZCH", style = MaterialTheme.typography.headlineSmall)
            Text("Состояние проверяется автоматически после возврата из настроек.")
            Text("${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} · Android ${android.os.Build.VERSION.RELEASE}")
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Главный экран: " + when {
                    state.effectiveHome -> "Android открывает EZCH"
                    state.roleMismatch -> "роль получена, но Android выбирает другой экран"
                    else -> "назначение не подтверждено"
                })
                state.resolvedHomeName?.let { Text("Системный обработчик HOME: $it") }
                if (state.otherHomeServices.isNotEmpty()) Text(
                    "Другие службы HOME: ${state.otherHomeServices.joinToString()}. Они могут перехватывать кнопку HOME. " +
                        "Отключите замену рабочего стола в настройках этих приложений, если хотите использовать EZCH.")
                Button(onClick = {
                    launchHomeRequest(HomeRole.requestIntent(context))
                }, enabled = !state.effectiveHome) { Text("Выбрать EZCH главным экраном") }
                if (!state.effectiveHome) OutlinedButton(onClick = {
                    launchHomeRequest(HomeRole.settingsIntent(context))
                }) { Text("Системный список рабочих столов") }
                Text("Служба кнопки Home: " + when {
                    state.serviceConnected -> "подключена к Android"
                    state.serviceEnabled -> "разрешена, но подключение не подтверждено"
                    else -> "выключена"
                })
                if (!state.effectiveHome) Text(when {
                    state.serviceConnected -> "Служба EZCH уже активна. На этой прошивке она возвращает в EZCH, когда кнопка Home открывает системный экран."
                    state.serviceEnabled -> "Служба разрешена, но Android ещё не подтвердил подключение. Подождите несколько секунд и проверьте кнопку Home на пульте."
                    else -> "Если телевизор удерживает штатный экран, включите службу EZCH. После этого проверьте кнопку Home на пульте: некоторые прошивки блокируют перенаправление."
                })
                Button(onClick = {
                    SettingsRouter.accessibility(context)
                    state = readHomeSetup(context)
                }) { Text(if (state.serviceConnected) "Настройки службы Home" else "Включить службу Home") }
                if (!state.serviceEnabled) {
                    Text("Если Android пишет «Ограниченная настройка», откройте свойства EZCH и разрешите ограниченные настройки, если такой пункт есть. Затем вернитесь и включите службу. Это подтверждение требует владельца телевизора.")
                    OutlinedButton(onClick = { SettingsRouter.appDetails(context) }) { Text("Открыть свойства EZCH") }
                }
                Text("Установка приложений: " + if (state.canInstall) "разрешена" else "нужно разрешение Android")
                Button(onClick = { SettingsRouter.installPermission(context) }, enabled = !state.canInstall) {
                    Text("Разрешить установку из EZCH")
                }
                if (state.homeAvailable && !state.effectiveHome) Text("Служба подключена. Системный маршрут HOME ведёт в другой экран. Проверьте возврат в EZCH кнопкой Home на пульте.")
                if (notice.isNotEmpty()) Text(notice)
            }
            Button(onClick = onClose) { Text("К рабочему столу") }
        }
    }
}
