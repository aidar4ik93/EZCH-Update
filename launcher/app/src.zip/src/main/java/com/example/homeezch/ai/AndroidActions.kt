package com.example.homeezch.ai

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import com.example.homeezch.MainActivity
import com.example.homeezch.UpdaterActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AndroidActionExecutor(private val context: Context,
    private val navigate: (suspend (Action.Navigate) -> Outcome)? = null,
    private val chooseApp: suspend (List<AppTarget>) -> AppTarget? = { null }) : ActionExecutor {
    fun apps(): List<AppTarget> {
        val pm = context.packageManager
        return listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER).flatMap { category ->
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(category), 0).mapNotNull {
                val info = it.activityInfo
                if (!info.exported || !info.enabled || !info.applicationInfo.enabled || info.packageName == context.packageName ||
                    !AiProfilePolicy.appAllowed(context, info.packageName)) null
                else AppTarget(it.loadLabel(pm).toString(), ComponentName(info.packageName, info.name).flattenToString())
            }
        }.distinctBy { it.component }.sortedBy { it.label }
    }
    override suspend fun execute(action: Action): Outcome {
        if (!LocalActionRegistry.allowed(action)) return Outcome(false, "Команда отклонена")
        return try {
            when (action) {
                is Action.PlayRequest -> execute(routePlayRequest(action, withContext(Dispatchers.IO) { apps() }))
                Action.Cancel -> Outcome(false, "Отменено")
                Action.Dismiss -> Outcome(false, "Помощник закрыт")
                Action.Weather -> spokenWeather(context)
                Action.Updates -> {
                    if (!AiProfilePolicy.updatesAllowed(context)) return Outcome(false, "Откройте Update вручную через защищённые настройки владельца")
                    context.startActivity(Intent(context, UpdaterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    Outcome(true, "Открытие EZCH Update запрошено")
                }
                is Action.Navigate -> if (navigate != null) navigate.invoke(action) else {
                    EvaAppService.current?.let { return it.execute(action) }
                    if (action.direction != Direction.HOME) Outcome(false, "Навигация доступна в EZCH HOME; управление чужим окном не подключено")
                    else { context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Outcome(true, "Открытие HOME запрошено") }
                }
                is Action.Launch -> {
                    val profile = com.example.homeezch.Profiles.active(context)
                    val before = withContext(Dispatchers.IO) { apps() }
                    val target = when (val match = matchApp(action.name, before)) {
                        AppMatch.Missing -> return Outcome(false, "Запускаемое приложение «${action.name}» не найдено")
                        is AppMatch.Unique -> match.app
                        is AppMatch.Ambiguous -> chooseApp(match.apps) ?: return Outcome(false, "Выбор приложения отменён")
                        is AppMatch.Suggested -> match.apps.singleOrNull() ?: chooseApp(match.apps) ?: return Outcome(false, "Выбор приложения отменён")
                    }
                    if (com.example.homeezch.Profiles.active(context) != profile) return Outcome(false, "Профиль изменился — повторите команду")
                    if (withContext(Dispatchers.IO) { apps() }.none { it.component == target.component }) return Outcome(false, "Приложение удалено или недоступно")
                    val component = ComponentName.unflattenFromString(target.component) ?: return Outcome(false, "Некорректное приложение")
                    context.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    val confirmed = EvaAppService.current?.confirmWindow(component.packageName) == true
                    Outcome(confirmed, if (confirmed) "Открыто ${target.label}" else "Запуск «${target.label}» запрошен; окно не подтверждено. Для цепочек включите управление приложениями в настройках Евы")
                }
                is Action.PlayChannel, is Action.Search, is Action.Choose, is Action.Quality, Action.Watch, Action.ClearCache ->
                    EvaAppService.current?.execute(action) ?: Outcome(false, "Включите «Ai EvA — управление приложениями» в специальных возможностях Android")
                Action.Settings -> {
                    context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    Outcome(true, "Открытие настроек запрошено")
                }
                is Action.Volume -> volume(action)
                is Action.Media -> AndroidMediaAdapter(context).setPlaying(action.play)
            }
        } catch (_: SecurityException) { Outcome(false, "Android запретил действие")
          } catch (_: android.content.ActivityNotFoundException) { Outcome(false, "Приложение недоступно") }
    }
    private suspend fun volume(action: Action.Volume): Outcome {
        val audio = context.getSystemService(AudioManager::class.java) ?: return Outcome(false, "Звук недоступен")
        if (audio.isVolumeFixed) return Outcome(false, "Громкостью управляет телевизор или внешний ресивер")
        val stream = AudioManager.STREAM_MUSIC
        val before = audio.getStreamVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val expected = action.percent?.let { (max * it / 100.0).toInt() }
        when {
            action.mute != null -> audio.adjustStreamVolume(stream, if (action.mute == true) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
            expected != null -> audio.setStreamVolume(stream, expected, 0)
            else -> audio.adjustStreamVolume(stream, if (action.step > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        }
        delay(120)
        val after = audio.getStreamVolume(stream)
        val verified = if (action.mute != null) audio.isStreamMute(stream) == action.mute
            else if (expected != null) after == expected
            else if (action.step > 0) after > before || before == max else after < before || before == 0
        return Outcome(verified, if (verified) "Громкость: ${if (max == 0) 0 else after * 100 / max}%" else "Изменение громкости не подтверждено")
    }
}

class AndroidMediaAdapter(private val context: Context) : MediaAdapter {
    fun isPlaying(packageName: String): Boolean? = try {
        val sessions = context.getSystemService(MediaSessionManager::class.java)
            ?.getActiveSessions(ComponentName(context, EzchMediaListener::class.java))
            ?.filter { it.packageName == packageName }.orEmpty()
        if (sessions.isEmpty()) null else sessions.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
    } catch (_: SecurityException) { null }
    override suspend fun setPlaying(play: Boolean): Outcome {
        val manager = context.getSystemService(MediaSessionManager::class.java) ?: return Outcome(false, "MediaSession недоступна")
        val sessions = try { manager.getActiveSessions(ComponentName(context, EzchMediaListener::class.java)) }
            catch (_: SecurityException) { return Outcome(false, "Разрешите доступ к медиасессиям в настройках EVA") }
        val playing = sessions.filter { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val paused = sessions.filter { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        val candidates = if (play) paused else playing
        if (candidates.size != 1) return Outcome(false, if (candidates.isEmpty()) "Нет подходящей медиасессии" else "Несколько плееров: выберите один вручную")
        val controller = candidates.single()
        val required = if (play) PlaybackState.ACTION_PLAY else PlaybackState.ACTION_PAUSE
        if (((controller.playbackState?.actions ?: 0L) and required) == 0L) return Outcome(false, "Плеер не поддерживает команду")
        if (play) controller.transportControls.play() else controller.transportControls.pause()
        val deadline = SystemClock.elapsedRealtime() + 1500
        do {
            delay(100)
            if (controller.playbackState?.state == if (play) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED)
                return Outcome(true, if (play) "Воспроизведение продолжено" else "Пауза")
        } while (SystemClock.elapsedRealtime() < deadline)
        return Outcome(false, "Команда отправлена плееру, результат не подтверждён")
    }
}
/** Required public MediaSession access; no notification contents are inspected or stored. */
class EzchMediaListener : android.service.notification.NotificationListenerService()
