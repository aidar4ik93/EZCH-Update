package com.example.homeezch.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** One user-initiated utterance. No audio buffers or transcripts persisted. */
class AndroidVoiceRecognizer(private val context: Context, private val status: (String) -> Unit,
    private val result: (String) -> Unit,
    private val amplitude: (Float) -> Unit = {}, private val partial: (String) -> Unit = {},
    private val forceNetwork: Boolean = false, private val fallback: ((Int) -> Boolean)? = null) : Recognizer, RecognitionListener {
    private val handler = Handler(Looper.getMainLooper())
    private var speech: SpeechRecognizer? = null
    private var active = false
    val isListening: Boolean get() = active
    private var generation = 0
    private val timeout = Runnable { cancel(); status("Время ожидания истекло") }
    override fun start() {
        destroy()
        AiPreferences.store(context).edit().remove("last_speech_error").putString("speech_state", "starting").apply()
        if (!AiPreferences.enabled(context)) { status("Помощник выключен"); return }
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status("Разрешите микрофон в настройках EVA"); return
        }
        val local = !forceNetwork && Build.VERSION.SDK_INT >= 31 && runCatching { SpeechRecognizer.isOnDeviceRecognitionAvailable(context) }.getOrDefault(false)
        AiPreferences.store(context).edit().putString("speech_mode", if (local) "on-device" else "system").apply()
        if (!local && !AiPreferences.networkSpeech(context)) {
            status("Локальный распознаватель недоступен. Сетевой ввод можно разрешить в настройках"); return
        }
        // The remote recognition provider manages audio focus itself. Taking focus here
        // makes its own request look like an interruption and cancels valid TV input.
        try {
            speech = if (local) SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else {
                // Explicit provider prevents recursion through our role metadata service.
                val providers = context.packageManager.queryIntentServices(Intent("android.speech.RecognitionService"), 0)
                    .filter { it.serviceInfo.packageName != context.packageName && it.serviceInfo.exported && it.serviceInfo.enabled }
                val configured = android.provider.Settings.Secure.getString(context.contentResolver, "voice_recognition_service")
                    ?.let(android.content.ComponentName::unflattenFromString)
                val provider = providers.firstOrNull { android.content.ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) == configured }
                    ?: providers.firstOrNull { it.serviceInfo.packageName == "com.google.android.katniss" }
                    ?: providers.firstOrNull { it.serviceInfo.packageName == "com.google.android.tts" }
                    ?: providers.singleOrNull()
                if (provider == null) { destroy(); status("Выберите доступный системный распознаватель"); return }
                SpeechRecognizer.createSpeechRecognizer(context, android.content.ComponentName(provider.serviceInfo.packageName, provider.serviceInfo.name))
            }
            active = true
            val token = generation
            val owner = this
            speech!!.setRecognitionListener(object : RecognitionListener {
                private fun live() = token == generation && active
                override fun onReadyForSpeech(params: Bundle?) { if (live()) owner.onReadyForSpeech(params) }
                override fun onBeginningOfSpeech() { if (live()) owner.onBeginningOfSpeech() }
                override fun onRmsChanged(value: Float) { if (live()) owner.onRmsChanged(value) }
                override fun onBufferReceived(buffer: ByteArray?) { if (live()) owner.onBufferReceived(buffer) }
                override fun onEndOfSpeech() { if (live()) owner.onEndOfSpeech() }
                override fun onError(error: Int) { if (live()) owner.onError(error) }
                override fun onResults(results: Bundle?) { if (live()) owner.onResults(results) }
                override fun onPartialResults(results: Bundle?) { if (live()) owner.onPartialResults(results) }
                override fun onEvent(type: Int, params: Bundle?) { if (live()) owner.onEvent(type, params) }
            })
            status(if (local) "Подключаю локальный микрофон…" else "Подключаю системный ввод — возможна передача аудио…")
            VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_START)
            speech!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, AiPreferences.store(context).getString("language", "ru-RU"))
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
            handler.postDelayed(timeout, 15000)
        } catch (_: RuntimeException) { destroy(); status("Не удалось подключить распознаватель") }
    }
    override fun cancel() { active = false; handler.removeCallbacks(timeout); speech?.cancel(); destroy() }
    override fun destroy() {
        active = false
        generation++
        handler.removeCallbacks(timeout)
        speech?.destroy(); speech = null
        amplitude(0f)
    }
    override fun onReadyForSpeech(params: Bundle?) { if (active) { VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_READY); AiPreferences.store(context).edit().putString("speech_state", "listening").apply(); status("Я слушаю…") } }
    override fun onBeginningOfSpeech() { if (active) { VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_SPEECH_BEGIN); status("Получаю речь…") } }
    override fun onEndOfSpeech() { if (active) { VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_SPEECH_END); status("Распознаю…") } }
    override fun onRmsChanged(rmsdB: Float) { if (active) amplitude(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
    override fun onBufferReceived(buffer: ByteArray?) { /* Never save raw audio. */ }
    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        if (active) partial(text)
        if (active && normalize(text) in listOf("стоп", "отмена")) { cancel(); status("Отменено") }
    }
    override fun onResults(results: Bundle?) {
        if (!active) return
        VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_RESULT)
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        destroy()
        VoiceTiming.mark(VoiceTiming.Phase.SYSTEM_RELEASED)
        if (text.isNullOrBlank()) status("Речь не распознана") else {
            AiPreferences.store(context).edit().putBoolean("ru_result", true).putString("speech_state", "recognized").apply()
            result(text)
        }
    }
    override fun onError(error: Int) {
        if (!active) return
        AiPreferences.store(context).edit().putInt("last_speech_error", error).putString("speech_state", "error").apply()
        destroy()
        if (fallback?.invoke(error) == true) return
        status(when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Аудиовход недоступен; микрофон пульта требует проверки"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения микрофона"
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "Русская модель недоступна"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Сетевой распознаватель недоступен"
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Речь не распознана"
            else -> "Ошибка распознавателя: $error"
        })
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
