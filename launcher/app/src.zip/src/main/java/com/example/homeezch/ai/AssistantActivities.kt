package com.example.homeezch.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.viewinterop.AndroidView
import com.example.homeezch.DesktopProfile
import com.example.homeezch.Profiles
import com.example.homeezch.PinPrompt
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class VoiceActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        setTheme(android.R.style.Theme_NoDisplay)
        super.onCreate(state)
        val control = EvaAppService.current
        if (control != null) control.showMiniPanel()
        else startActivity(Intent(this, com.example.homeezch.MainActivity::class.java)
            .putExtra("ezch.voice.start", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}

class AssistantSettingsActivity : ComponentActivity() {
    private lateinit var report: TextView
    private var probeJob: kotlinx.coroutines.Job? = null
    private var unlocked by mutableStateOf(false)
    private var guard by mutableStateOf<DesktopProfile?>(null)
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        guard = Profiles.guard(this)
        unlocked = guard == null || AiSettingsTicket.consume(this, intent.getStringExtra("authorization"))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val profile = guard
                if (unlocked || profile == null) AndroidView(factory = { buildContent() })
                else PinPrompt(profile, ::finish) { unlocked = true }
            }
        }
    }
    private fun buildContent(): android.view.View {
        val store = AiPreferences.store(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(26, 16, 26, 16) }
        report = TextView(this).apply { textSize = 15f; setTextColor(android.graphics.Color.WHITE) }
        column.addView(TextView(this).apply { text = "Голосовой помощник EVA"; textSize = 22f; setTextColor(android.graphics.Color.CYAN) })
        column.addView(Switch(this).apply {
            text = "Включить помощник и кнопку в HOME"; isChecked = AiPreferences.enabled(this@AssistantSettingsActivity)
            setOnCheckedChangeListener { _, checked -> if (!checked) probeJob?.cancel(); store.edit().putBoolean("enabled", checked).apply(); refresh() }
        })
        column.addView(Switch(this).apply {
            text = "Отзываться на «Ева» без пульта, пока открыт рабочий стол\nИспользует микрофон. Выключено по умолчанию."
            isChecked = EvaEngine.handsFreeEnabled(this@AssistantSettingsActivity)
            setOnCheckedChangeListener { _, checked -> EvaEngine.setHandsFree(this@AssistantSettingsActivity, checked) }
        })
        column.addView(Switch(this).apply {
            text = "Разрешить системный сетевой ввод речи\nВыбранный движок может передавать звук на свои серверы"; isChecked = AiPreferences.networkSpeech(this@AssistantSettingsActivity)
            setOnCheckedChangeListener { _, checked -> store.edit().putBoolean("network_speech", checked).apply() }
        })
        fun button(title: String, action: () -> Unit) { column.addView(Button(this).apply { text = title; isAllCaps = false; setOnClickListener { action() } }) }
        button("Разрешить микрофон") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 72) }
        button("Управление приложениями · разрешить в Android") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        column.addView(Switch(this).apply {
            text = "Озвучивать ответы Евы"; isChecked = store.getBoolean("tts", true)
            setOnCheckedChangeListener { _, checked -> store.edit().putBoolean("tts", checked).apply() }
        })
        column.addView(TextView(this).apply { text = "GLM · ответы на общие вопросы"; textSize = 19f; setTextColor(android.graphics.Color.CYAN) })
        val cloudStore = GlmConnection.store(this)
        val endpoint = EditText(this).apply {
            hint = "Адрес сервера Евы · https://…"; setSingleLine()
            setText(cloudStore.getString("endpoint", "http://127.0.0.1:8765"))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val pairing = EditText(this).apply {
            hint = "Код подключения · 6 цифр"; setSingleLine(); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val cloudConsent = Switch(this).apply {
            text = "Разрешить GLM обработку текста вопросов и короткого диалога\nЗвук, экран и список приложений в GLM не отправляются"
            isEnabled = GlmConnection.configured(this@AssistantSettingsActivity)
            isChecked = GlmConnection.consent(this@AssistantSettingsActivity)
            setOnCheckedChangeListener { _, checked ->
                cloudStore.edit().putBoolean("text_consent_" + Profiles.active(this@AssistantSettingsActivity), checked).apply()
                if (!checked) EvaAppService.current?.hideMiniPanel()
            }
        }
        column.addView(endpoint); column.addView(pairing)
        button("Подключить GLM по коду") {
            probeJob?.cancel()
            val address = endpoint.text.toString().trim()
            val code = pairing.text.toString().trim()
            probeJob = lifecycleScope.launch {
                report.text = "Подключаю сервер Евы…"
                val connected = GlmConversation.pair(this@AssistantSettingsActivity, address, code)
                cloudConsent.isChecked = false; cloudConsent.isEnabled = GlmConnection.configured(this@AssistantSettingsActivity)
                if (connected) pairing.text.clear()
                report.text = if (connected) "Сервер подключён. Включите разрешение на обработку текста вопросов."
                    else "Подключение не выполнено. Проверьте адрес, код и доступность сервера."
            }
        }
        column.addView(cloudConsent)
        button("Отключить GLM") {
            probeJob?.cancel(); cloudStore.edit().clear().apply(); cloudConsent.isChecked = false; cloudConsent.isEnabled = false
            EvaAppService.current?.hideMiniPanel(); report.text = "GLM отключён. Локальные команды доступны."
        }
        column.addView(Switch(this).apply {
            text = "English recognition (выключено — русский)"; isChecked = store.getString("language", "ru-RU") == "en-US"
            setOnCheckedChangeListener { _, checked -> store.edit().putString("language", if (checked) "en-US" else "ru-RU").apply() }
        })
        column.addView(TextView(this).apply { text = "Запуск: кнопка Евы в лаунчере или поддерживаемая кнопка микрофона. Значок не забирает фокус пульта. Нажатие значка — говорить, долгое нажатие — закрыть; автоматическое закрытие после 30 секунд бездействия. Для офлайн-речи нужна локальная модель."; setTextColor(android.graphics.Color.LTGRAY) })
        button("Проверить аудиовход · 3 секунды без сохранения звука") {
            probeJob?.cancel()
            probeJob = lifecycleScope.launch {
                report.text = "Говорите в микрофон пульта. Проверяю поток звука…"
                val sample = PcmAudioProbe(this@AssistantSettingsActivity).capture()
                store.edit().putString("pcm_probe", sample).apply(); refresh()
            }
        }
        button("Назначить EVA основным помощником") {
            if (!AndroidCapabilityProbe(this).openAssistantSettings(this)) Toast.makeText(this, "В прошивке нет экрана выбора голосового помощника. Запускайте EVA кнопкой на рабочем столе", Toast.LENGTH_LONG).show()
        }
        button("Доступ к медиасессиям · по желанию") {
            runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.onFailure {
                Toast.makeText(this, "Системный экран недоступен", Toast.LENGTH_LONG).show()
            }
        }
        column.addView(TextView(this).apply { text = "Android выдаёт доступ к уведомлениям. EVA использует его только для управления плеером, содержимое уведомлений не читает."; setTextColor(android.graphics.Color.LTGRAY) })
        button("Проверить голос / запуск из EZCH") {
            val control = EvaAppService.current
            if (control != null) control.showMiniPanel()
            else Toast.makeText(this, "Включите службу Ai EvA в специальных возможностях", Toast.LENGTH_LONG).show()
        }
        button("Обновить диагностику") { refresh() }
        button("Очистить только диагностику EVA") { store.edit().remove("session_seen").remove("ru_result").remove("pcm_probe").apply(); refresh() }
        column.addView(report)
        button("Назад") { finish() }
        refresh()
        return ScrollView(this).apply { setBackgroundColor(android.graphics.Color.rgb(5, 10, 20)); addView(column) }
    }
    private fun refresh() { if (::report.isInitialized) report.text = AndroidCapabilityProbe(this).report() }
    override fun onResume() { super.onResume(); guard = Profiles.guard(this); refresh() }
    override fun onStop() { if (guard != null) unlocked = false; super.onStop() }
    override fun onPause() { probeJob?.cancel(); super.onPause() }
    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results); refresh()
    }
}
