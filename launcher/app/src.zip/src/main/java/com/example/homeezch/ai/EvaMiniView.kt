package com.example.homeezch.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.min

/** Entire assistant fits within two thirds of an application tile. No backdrop or status panel. */
class EvaMiniView(context: Context) : EvaSphereView(context) {
    private val brush = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var artwork: Bitmap? = null
    init { isFocusable = false; isFocusableInTouchMode = false }
    override fun onDraw(canvas: Canvas) {
        val side = min(width, height).toFloat()
        if (side <= 0f) return
        val artSize = (side * 1.18f).toInt().coerceAtLeast(1)
        if (artwork?.width != artSize) { artwork?.recycle(); artwork = EvaOrbArtwork.create(artSize) }
        val cx = width / 2f; val cy = height / 2f
        brush.alpha = 255
        artwork?.let { canvas.drawBitmap(it, cx - it.width / 2f, cy - it.height / 2f, brush) }
        // Small real-audio meter stays inside the icon's bounds.
        if (amplitude > .015f) {
            brush.color = Color.rgb(144, 194, 255); brush.alpha = 190
            brush.strokeWidth = (side * .012f).coerceAtLeast(1f)
            for (i in 0..3) {
                val level = side * (.015f + amplitude * (.022f + i * .008f))
                for (direction in listOf(-1, 1)) {
                    val x = cx + direction * side * (.31f + i * .028f)
                    canvas.drawLine(x, cy - level, x, cy + level, brush)
                }
            }
        }
        contentDescription = "Ева. $message"
        if (busy && isShown && windowVisibility == VISIBLE) postInvalidateDelayed(50)
    }
    override fun onDetachedFromWindow() { artwork?.recycle(); artwork = null; super.onDetachedFromWindow() }
}
