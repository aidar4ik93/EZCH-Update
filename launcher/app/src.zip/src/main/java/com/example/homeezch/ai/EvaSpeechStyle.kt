package com.example.homeezch.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Call on the speech worker: vendor TTS calls may wait for a Binder connection. */
internal object EvaSpeechStyle {
    fun configure(context: Context, engine: TextToSpeech, locale: Locale): Boolean {
        engine.setLanguage(locale)
        val voices = engine.voices.orEmpty().filter {
            it.locale.language == locale.language && !it.isNetworkConnectionRequired &&
                TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED !in it.features.orEmpty()
        }
        val requested = AiPreferences.store(context).getString("tts_voice", null)
        // These local voices were exported and verified on Dongle_G_4K. Other engines use a local locale fallback.
        val preferred = listOfNotNull(requested) + if (locale.language == "ru")
            listOf("ru-ru-x-ruc-local", "ru-ru-x-dfc-local", "ru-ru-x-rue-local") else emptyList()
        val candidates = voices.sortedWith(compareBy<android.speech.tts.Voice> {
            preferred.indexOf(it.name).takeIf { rank -> rank >= 0 } ?: Int.MAX_VALUE
        }.thenByDescending { it.quality })
        val selected = candidates.firstOrNull {
            engine.setVoice(it) == TextToSpeech.SUCCESS && engine.voice?.name == it.name
        }
        engine.setSpeechRate(1.12f)
        engine.setPitch(1f)
        AiPreferences.store(context).edit().putString("tts_voice_active", selected?.name).apply()
        return selected != null
    }
}
