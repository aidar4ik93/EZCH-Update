package com.example.homeezch.ai

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URI
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

internal object GlmConnection {
    fun store(context: Context) = context.getSharedPreferences("eva_cloud_v1", Context.MODE_PRIVATE)
    fun validEndpoint(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.host?.isNotBlank() == true && uri.rawUserInfo == null && uri.rawQuery == null && uri.rawFragment == null &&
            uri.path.orEmpty() in setOf("", "/") && (uri.port == -1 || uri.port in 1..65535) &&
            (uri.scheme == "https" || (uri.scheme == "http" && uri.host == "127.0.0.1"))
    }.getOrDefault(false)
    fun configured(context: Context): Boolean {
        val prefs = store(context)
        return validEndpoint(prefs.getString("endpoint", "").orEmpty()) && prefs.getString("token", "").orEmpty().length in 32..128
    }
    fun consent(context: Context) = store(context).getBoolean("text_consent_" + com.example.homeezch.Profiles.active(context), false)
    fun enabled(context: Context) = consent(context) && configured(context)
}

/** A text-only gateway. Cloud output is never converted to an Action or executed. */
internal class GlmConversation(private val context: Context) {
    private val history = ArrayDeque<Pair<String, String>>()
    private var historyProfile: String? = null
    private var historyEndpoint = ""
    private var lastReplyAt = 0L
    companion object {
        private val client by lazy { OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS).callTimeout(14, TimeUnit.SECONDS)
            .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false).build() }
        private val jsonType = "application/json; charset=utf-8".toMediaType()
        internal fun safeReply(value: String) = value.isNotBlank() && value.length <= 1200 && value.none { it.isISOControl() && !it.isWhitespace() }
        private suspend fun post(endpoint: String, path: String, json: JSONObject, token: String? = null): JSONObject? = withContext(Dispatchers.IO) { suspendCancellableCoroutine { continuation ->
            val request = Request.Builder().url(endpoint.trimEnd('/') + path)
                .post(json.toString().toRequestBody(jsonType)).apply { token?.let { header("Authorization", "Bearer $it") } }.build()
            val call = client.newCall(request)
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { if (continuation.isActive) continuation.resume(null) }
                override fun onResponse(call: Call, response: Response) {
                    val result = runCatching { response.use {
                        if (!it.isSuccessful) return@use null
                        val stream = it.body?.byteStream() ?: return@use null
                        val bytes = ByteArray(8193); var size = 0
                        while (size < bytes.size) { val count = stream.read(bytes, size, bytes.size - size); if (count < 0) break; if (count == 0) continue; size += count }
                        if (size > 8192) null else JSONObject(String(bytes, 0, size, Charsets.UTF_8))
                    } }.getOrNull()
                    if (continuation.isActive) continuation.resume(result)
                }
            })
        } }
        suspend fun pair(context: Context, endpoint: String, code: String): Boolean {
            if (!GlmConnection.validEndpoint(endpoint) || !code.matches(Regex("[0-9]{6}"))) return false
            val profile = com.example.homeezch.Profiles.active(context)
            val reply = post(endpoint, "/v1/pair", JSONObject().put("code", code)) ?: return false
            if (com.example.homeezch.Profiles.active(context) != profile) return false
            val token = reply.optString("token")
            if (!token.matches(Regex("[A-Za-z0-9_-]{32,128}"))) return false
            // A new server must never inherit another profile's consent for the previous server.
            GlmConnection.store(context).edit().clear().putString("endpoint", endpoint.trimEnd('/')).putString("token", token)
                .putBoolean("text_consent_$profile", false).apply()
            return true
        }
    }
    fun clear() { history.clear(); historyProfile = null; historyEndpoint = ""; lastReplyAt = 0 }
    suspend fun reply(text: String, profile: String): String {
        val prefs = GlmConnection.store(context)
        val endpoint = prefs.getString("endpoint", "").orEmpty()
        val token = prefs.getString("token", "").orEmpty()
        if (!GlmConnection.enabled(context) || text.isBlank() || text.length > 600 || text.any { it.isISOControl() && !it.isWhitespace() }) {
            clear(); return "GLM не подключён. Откройте настройки Евы."
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (historyProfile != profile || historyEndpoint != endpoint || now - lastReplyAt > 120_000) clear()
        historyProfile = profile; historyEndpoint = endpoint
        while (history.size > 4 || history.sumOf { it.second.length } > 3000) { history.removeFirst(); history.removeFirst() }
        val messages = JSONArray().apply { history.forEach { (role, content) -> put(JSONObject().put("role", role).put("content", content)) } }
        val response = post(endpoint, "/v1/reply", JSONObject().put("text", text).put("history", messages), token)
        if (!GlmConnection.enabled(context) || prefs.getString("endpoint", "") != endpoint || prefs.getString("token", "") != token ||
            com.example.homeezch.Profiles.active(context) != profile || !AiPreferences.enabled(context)) { clear(); throw CancellationException("Connection or owner changed") }
        val answer = response?.optString("reply").orEmpty().trim()
        if (!safeReply(answer)) { clear(); return "GLM сейчас не ответил. Попробуйте немного позже." }
        history.addLast("user" to text); history.addLast("assistant" to answer)
        lastReplyAt = android.os.SystemClock.elapsedRealtime()
        return answer
    }
}
