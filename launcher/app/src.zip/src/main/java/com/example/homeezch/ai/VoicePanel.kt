package com.example.homeezch.ai

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Button
import android.view.View
import android.view.KeyEvent
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.*
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.sqrt

/** One shared reference UI for the in-launcher Activity and the system assistant. */
class VoicePanel(private val context: Context, private val homeResult: ((String) -> Unit)? = null,
    private val close: () -> Unit, compact: Boolean = false, private val mini: Boolean = true,
    private val onActivity: () -> Unit = {}, private val onStatusText: (String) -> Unit = {}) : OverlayPresenter {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var pendingChoice: CancellableContinuation<AppTarget?>? = null
    private var options: List<AppTarget> = emptyList()
    private var executing = false
    private val conversation = GlmConversation(context)
    @Volatile private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingReply: String? = null
    @Volatile private var destroyed = false
    // TV TTS engines can hold their internal lock while connecting over Binder.
    // Never wait for that lock on the launcher's UI thread (confirmed in TV ANR).
    private val speechWorker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val speechGeneration = java.util.concurrent.atomic.AtomicInteger()
    private fun speechTask(action: () -> Unit) { if (!speechWorker.isShutdown) runCatching { speechWorker.execute { runCatching(action) } } }
    private fun stopSpeech() { speechGeneration.incrementAndGet(); val engine = tts; speechTask { engine?.stop() } }
    private val sphere = (if (mini) EvaMiniView(context) else EvaSphereView(context)).apply { this.compact = compact }
    private val textInput = EditText(context).apply { hint = "Команда Еве"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
    private val editor = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL; visibility = View.GONE
        setPadding(20, 12, 20, 12); setBackgroundColor(0xF0080712.toInt())
        addView(textInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(Button(context).apply { text = "Выполнить"; isAllCaps = false; setOnClickListener { val command = textInput.text.toString(); hideEditor(); submit(command) } })
        addView(Button(context).apply { text = "Закрыть"; isAllCaps = false; setOnClickListener { hideEditor() } })
    }
    private val root = FrameLayout(context).apply {
        addView(sphere, FrameLayout.LayoutParams(-1, -1))
        if (!mini) addView(editor, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }
    private val recognizer = HybridVoiceRecognizer(context, ::recognitionStatus, ::submit,
        amplitude = { sphere.amplitude = it }, partial = { sphere.transcript = it })
    val view: android.view.View get() = root
    fun setCompact(value: Boolean) { sphere.compact = value }
    fun handleKey(code: Int, event: KeyEvent): Boolean = if (editor.visibility == View.VISIBLE) false else sphere.onKeyDown(code, event)
    init {
        sphere.onListen = ::listen
        sphere.onText = ::textCommand
        sphere.onSettings = { context.startActivity(Intent(context, AssistantSettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        if (mini) sphere.setOnLongClickListener { close(); true } else sphere.requestFocus()
        status(if (AiPreferences.enabled(context)) "Нажмите OK" else "Ева выключена · Меню — настройки")
        if (AiPreferences.store(context).getBoolean("tts", true)) {
          speechTask initialize@ {
            if (destroyed) return@initialize
            tts = TextToSpeech(context.applicationContext) { code ->
                if (!destroyed && code == TextToSpeech.SUCCESS) {
                    speechTask configure@ {
                        if (destroyed) return@configure
                        val engine = tts ?: return@configure
                        val locale = Locale.forLanguageTag(AiPreferences.store(context).getString("language", "ru-RU") ?: "ru-RU")
                        val ready = EvaSpeechStyle.configure(context, engine, locale)
                        sphere.post {
                            if (!destroyed) {
                                ttsReady = ready
                                pendingReply?.let { pendingReply = null; answer(it) }
                            }
                        }
                    }
                }
            }
            if (destroyed) { tts?.shutdown(); tts = null; return@initialize }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { VoiceTiming.mark(VoiceTiming.Phase.TTS_STARTED); sphere.post { sphere.busy = true } }
                override fun onDone(id: String?) { sphere.post { sphere.busy = false; sphere.amplitude = 0f } }
                @Deprecated("Platform callback") override fun onError(id: String?) { sphere.post { sphere.busy = false; sphere.amplitude = 0f } }
                override fun onBeginSynthesis(id: String?, sampleRateInHz: Int, audioFormat: Int, channelCount: Int) { format = audioFormat }
                private var format = android.media.AudioFormat.ENCODING_PCM_16BIT
                override fun onAudioAvailable(id: String?, audio: ByteArray?) {
                    val bytes = audio ?: return
                    if (format != android.media.AudioFormat.ENCODING_PCM_16BIT || bytes.size < 2) return
                    var sum = 0.0
                    for (i in 0 until bytes.size - 1 step 2) { val s = ((bytes[i].toInt() and 255) or (bytes[i+1].toInt() shl 8)).toShort().toDouble(); sum += s*s }
                    val level = (sqrt(sum / (bytes.size / 2)) / 8000).toFloat().coerceIn(0f, 1f)
                    sphere.post { sphere.amplitude = level }
                }
            })
          }
        }
    }
    override fun status(message: String) { sphere.message = message; onActivity(); onStatusText(message); if (!executing && !message.endsWith("…") && !message.startsWith("Подключаю")) sphere.busy = false }
    private fun recognitionStatus(message: String) {
        status(message)
        if (AiPreferences.enabled(context) && !recognizer.isListening && !message.endsWith("…") && !message.startsWith("Подключаю")) answer(message)
    }
    fun listen() {
        if (pendingChoice?.isActive == true) {
            pendingReply = null; stopSpeech(); sphere.busy = true; recognizer.start(); return
        }
        cancel(false); sphere.transcript = ""; sphere.busy = true; recognizer.start()
    }
    private fun textCommand() {
        if (mini) { status("Компактный голосовой режим"); return }
        recognizer.cancel(); stopSpeech(); sphere.busy = false
        editor.visibility = View.VISIBLE; textInput.requestFocus()
        textInput.post { context.getSystemService(InputMethodManager::class.java)?.showSoftInput(textInput, InputMethodManager.SHOW_IMPLICIT) }
    }
    private fun hideEditor() { context.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(textInput.windowToken, 0); editor.visibility = View.GONE; sphere.requestFocus() }
    fun submit(text: String) {
        VoiceTiming.mark(VoiceTiming.Phase.COMMAND_RECEIVED)
        val reply = normalize(text).replace(Regex("^(?:ева|eva)[, ]+"), "").trimEnd('.', '!', '?')
        if (pendingChoice?.isActive == true && reply in setOf("нет", "не надо", "no")) {
            pendingChoice?.resume(null); pendingChoice = null; options = emptyList(); return
        }
        if (pendingChoice?.isActive == true && options.size == 1 && reply in setOf("да", "да открой", "открой", "yes")) {
            pendingChoice?.resume(options.single()); pendingChoice = null; options = emptyList(); return
        }
        // An ordinal must resolve a pending question rather than cancel it first.
        val resolution = LocalIntentResolver().resolve(text)
        if (pendingChoice?.isActive == true && resolution is Resolution.Plan && resolution.actions.singleOrNull() is Action.Choose) {
            val index = (resolution.actions.single() as Action.Choose).index
            val chosen = options.getOrNull(index - 1) ?: run { status("Варианта $index нет"); return }
            pendingChoice?.resume(chosen); pendingChoice = null; options = emptyList(); return
        }
        job?.cancel(); clearChoice(); recognizer.cancel(); stopSpeech(); sphere.transcript = text
        if (!AiPreferences.enabled(context)) { status("Помощник выключен"); return }
        if (resolution is Resolution.Rejected) {
            if (!GlmConnection.enabled(context) || text.isBlank() || text.length > 600 || text.any { it.isISOControl() && !it.isWhitespace() }) {
                answer(resolution.message); return
            }
            val profile = com.example.homeezch.Profiles.active(context)
            job = scope.launch {
                executing = true; sphere.busy = true; status("Думаю с GLM…")
                try {
                    val response = conversation.reply(text, profile)
                    ensureActive()
                    if (!destroyed && AiPreferences.enabled(context) && GlmConnection.enabled(context) &&
                        com.example.homeezch.Profiles.active(context) == profile) answer(response)
                } finally { executing = false; sphere.busy = false; sphere.amplitude = 0f }
            }
            return
        }
        val plan = (resolution as Resolution.Plan).actions
        if (plan.any { it == Action.Dismiss }) { cancel(false); close(); return }
        if (plan.any { it == Action.Cancel }) { conversation.clear(); cancel(); return }
        if (homeResult != null && plan.all { it is Action.Navigate }) {
            homeResult.invoke(text); return
        }
        job = scope.launch {
            executing = true; sphere.busy = true
            try {
                val executor = AndroidActionExecutor(context, chooseApp = ::choose)
                for (action in plan) {
                    ensureActive(); status(when(action) { is Action.Search -> "Ищу ${action.query}"; is Action.Launch -> "Открываю ${action.name}"; Action.Weather -> "Узнаю погоду…"; else -> "Выполняю…" })
                    val outcome = executor.execute(action)
                    VoiceTiming.mark(VoiceTiming.Phase.ACTION_READY)
                    ensureActive(); status(outcome.message)
                    if (!outcome.accepted) { answer(outcome.message); return@launch }
                }
                answer(sphere.message)
            } finally { executing = false; sphere.busy = false; sphere.amplitude = 0f }
        }
    }
    private fun answer(text: String) {
        status(text); sphere.busy = false; sphere.amplitude = 0f
        if (AiPreferences.store(context).getBoolean("tts", true)) {
            if (ttsReady) {
                val token = speechGeneration.get(); val engine = tts
                speechTask { if (speechGeneration.get() == token) { VoiceTiming.mark(VoiceTiming.Phase.TTS_REQUESTED); engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "eva-response") } }
            } else pendingReply = text
        }
    }
    private suspend fun choose(apps: List<AppTarget>): AppTarget? = suspendCancellableCoroutine { continuation ->
        pendingChoice = continuation; options = apps
        answer(if (apps.size == 1) "Открыть ${apps.single().label}? Скажите «да» или «нет»" else
            "Какое приложение открыть? " + apps.mapIndexed { i, app -> "${i + 1}. ${app.label}" }.joinToString(". "))
        continuation.invokeOnCancellation { options = emptyList() }
    }
    private fun clearChoice() { pendingChoice?.cancel(); pendingChoice = null; options = emptyList(); sphere.onListen = ::listen }
    fun pause() { recognizer.cancel(); if (!executing) stopSpeech() }
    fun cancel(showStatus: Boolean = true) { pendingReply = null; job?.cancel(); clearChoice(); recognizer.cancel(); stopSpeech(); sphere.busy = false; sphere.amplitude = 0f; if (showStatus) status("Отменено") }
    fun destroy() { destroyed = true; conversation.clear(); cancel(false); hideEditor(); recognizer.destroy(); val engine = tts; tts = null; speechTask { engine?.shutdown() }; speechWorker.shutdown(); scope.cancel() }
}
