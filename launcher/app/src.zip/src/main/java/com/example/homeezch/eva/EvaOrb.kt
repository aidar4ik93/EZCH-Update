package com.example.homeezch.eva

import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Live EVA orb for Compose. Hosts [EvaOrbView], whose Choreographer clock runs only while
 * HOME's window is visible; animation never recomposes or keeps Compose busy.
 */
@Composable
fun EvaOrb(state: EvaState, quality: EvaQuality, modifier: Modifier = Modifier, platform: Boolean = true) {
    key(quality, platform) {
        AndroidView(factory = { EvaOrbView(it, quality, platform) }, modifier = modifier,
            update = { view -> view.stateOverride = state })
    }
}
