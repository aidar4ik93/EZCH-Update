package com.example.homeezch.eva

import android.content.Context
import android.graphics.Canvas
import android.view.Choreographer
import android.view.View
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * The EVA orb as a plain View driven by Choreographer. Used directly by the voice panel
 * and the system assistant session, and hosted in Compose on the home screen: View
 * invalidation never keeps the Compose recomposer busy, so UI stays idle-testable.
 * Frames run only while the window is visible; resting states settle and stop.
 */
class EvaOrbView(context: Context, private val quality: EvaQuality, private val platform: Boolean = false) : View(context) {
    private val renderer = EvaRenderer()
    private val animator = EvaAnimator(quality.ribbons)
    private var busState = EvaBus.signal.value.state
    /** Set by Compose hosts that pass an explicit state; null follows [EvaBus]. */
    var stateOverride: EvaState? = null
        set(value) { field = value; restart() }
    private val state get() = stateOverride ?: busState
    private var lastFrame = 0L
    private var scope: CoroutineScope? = null
    private var job: Job? = null
    private var running = false
    private var windowShown = true
    /** Guards callbacks the platform may deliver before this subclass is initialised. */
    private var ready = false

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!running) return
            val fps = evaFps(state, quality)
            val minGap = if (fps <= 0) Long.MAX_VALUE else 1_000_000_000L / fps - 2_000_000L
            if (lastFrame == 0L) lastFrame = now
            if (now - lastFrame >= minGap || animator.settling) {
                animator.step((now - lastFrame) / 1e9f, state, EvaBus.level)
                lastFrame = now
                invalidate()
            }
            if (fps > 0 || animator.settling) Choreographer.getInstance().postFrameCallback(this)
            else running = false
        }
    }

    init { ready = true }

    private fun canRun() = ready && isAttachedToWindow && visibility == VISIBLE && windowShown

    private fun start() {
        if (running || !canRun()) return
        running = true; lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(callback)
    }

    private fun stop() {
        if (!ready) return
        running = false; Choreographer.getInstance().removeFrameCallback(callback)
    }

    private fun restart() { if (ready) { invalidate(); start() } }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate).also { s ->
            job = s.launch { EvaBus.signal.collect { busState = it.state; restart() } }
        }
        start()
    }

    override fun onDetachedFromWindow() {
        stop(); job?.cancel(); scope?.cancel(); scope = null
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (!ready) return
        if (visibility == VISIBLE) start() else stop()
    }

    /** HOME stopped or covered by another app: release the frame clock entirely. */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (!ready) return
        windowShown = visibility == VISIBLE
        if (windowShown) start() else stop()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!ready) return
        renderer.draw(canvas, width.toFloat(), height.toFloat(), animator, state, quality, platform)
    }
}
