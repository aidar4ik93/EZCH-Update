package com.example.homeezch.eva

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** EZCH Cosmic EVA design tokens (master prompt v5.0, category 8). */
object EvaTokens {
    val Background = Color(0xFF030510)
    val Surface = Color(0xFF0A1020)
    val ElectricBlue = Color(0xFF168BFF)
    val Cyan = Color(0xFF00DFFF)
    val Violet = Color(0xFF7945FF)
    val Magenta = Color(0xFFD34BFF)
    val PrimaryText = Color(0xFFF5F7FF)
    val SecondaryText = Color(0xFFB9C3E6)

    /** Semi-transparent glass panels with soft borders. */
    val Glass = Surface.copy(alpha = .62f)
    val GlassBorder = Color(0xFF2A3A63)
    val FocusBorder = Cyan
    val PanelShape = RoundedCornerShape(22.dp)
    val ChipShape = RoundedCornerShape(50)
}
