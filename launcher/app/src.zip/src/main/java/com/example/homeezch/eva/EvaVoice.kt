package com.example.homeezch.eva

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.homeezch.ai.AiPreferences
import java.util.Locale

/**
 * Optional spoken replies through the system TextToSpeech engine (works offline when
 * a Russian voice is installed). Drives SPEAKING with real progress callbacks: the
 * wave level follows onRangeStart (word boundaries) where the engine reports it.
 */
class EvaVoice(context: Context) {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var counter = 0

    private fun engine(): TextToSpeech? {
        tts?.let { return it }
        return runCatching {
            TextToSpeech(app) { status ->
                ready = status == TextToSpeech.SUCCESS && tts?.let { engine ->
                    val result = engine.setLanguage(Locale.forLanguageTag("ru-RU"))
                    result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                } == true
                if (ready) pending?.let { speakNow(it) }
                pending = null
            }.also { engine ->
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { EvaBus.pulse(.6f); EvaBus.send(EvaEvent.SpeakStart) }
                    override fun onDone(id: String?) { EvaBus.send(EvaEvent.SpeakDone) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { EvaBus.send(EvaEvent.SpeakDone) }
                    override fun onError(id: String?, code: Int) { EvaBus.send(EvaEvent.SpeakDone) }
                    override fun onStop(id: String?, interrupted: Boolean) { EvaBus.send(EvaEvent.SpeakDone) }
                    override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) {
                        EvaBus.pulse(.45f + ((end - start).coerceAtMost(10)) / 18f)
                    }
                })
                tts = engine
            }
        }.getOrNull()
    }

    fun speak(text: String) {
        if (text.isBlank() || !enabled(app)) return
        val engine = engine() ?: return
        if (ready && engine === tts) speakNow(text) else pending = text
    }

    private fun speakNow(text: String) {
        val engine = tts ?: return
        engine.speak(text.take(400), TextToSpeech.QUEUE_FLUSH, Bundle(), "eva-${counter++}")
    }

    fun stop() { runCatching { tts?.stop() }; pending = null }
    fun shutdown() { stop(); runCatching { tts?.shutdown() }; tts = null; ready = false }

    companion object {
        fun enabled(context: Context) = AiPreferences.store(context).getBoolean("speak_replies", true)
        fun setEnabled(context: Context, value: Boolean) =
            AiPreferences.store(context).edit().putBoolean("speak_replies", value).apply()
    }
}
