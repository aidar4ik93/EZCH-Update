package com.example.homeezch.eva

/** Level of dynamic wallpaper and EVA effects. Ordered from cheapest to richest. */
enum class GraphicsTier { STATIC, AMBIENT, CINEMATIC }

/** User setting; AUTO follows device resources and live frame/thermal/power health. */
enum class GraphicsChoice { AUTO, STATIC, AMBIENT, CINEMATIC }

/** Renderer budget for one tier. */
data class EvaQuality(
    val ribbons: Int,
    val segments: Int,
    val glowPasses: Int,
    val maxFps: Int,
    val particles: Int,
    val bloom: Boolean,
    val platform: Boolean,
    /** Frame cap for resting states (IDLE/OFFLINE); 0 freezes the orb until something happens. */
    val idleFps: Int
) {
    companion object {
        fun of(tier: GraphicsTier) = when (tier) {
            // 1–1.5 GB TVs: frozen idle frame; interaction states still animate at a low rate.
            GraphicsTier.STATIC -> EvaQuality(4, 40, 2, 20, 0, bloom = false, platform = true, idleFps = 0)
            GraphicsTier.AMBIENT -> EvaQuality(4, 56, 2, 30, 16, bloom = true, platform = true, idleFps = 24)
            GraphicsTier.CINEMATIC -> EvaQuality(6, 72, 3, 60, 40, bloom = true, platform = true, idleFps = 30)
        }
    }
}

object GraphicsPolicy {
    const val LITE_RAM_BYTES = 3L * 1024 * 1024 * 1024 / 2
    const val AMBIENT_RAM_BYTES = 2L * 1024 * 1024 * 1024

    /**
     * Weak hardware first: low RAM or Lite theme → STATIC; resource pressure
     * (memory, heat, power saving, slow frames) → AMBIENT at most.
     */
    fun auto(premium: Boolean, heavyEffects: Boolean, totalRam: Long, lowRamDevice: Boolean): GraphicsTier = when {
        !premium || lowRamDevice || totalRam <= LITE_RAM_BYTES -> GraphicsTier.STATIC
        !heavyEffects || totalRam <= AMBIENT_RAM_BYTES -> GraphicsTier.AMBIENT
        else -> GraphicsTier.CINEMATIC
    }

    /** A manual choice is honoured, but heavy effects are never started under pressure. */
    fun resolve(choice: GraphicsChoice, premium: Boolean, heavyEffects: Boolean, totalRam: Long, lowRamDevice: Boolean): GraphicsTier {
        val automatic = auto(premium, heavyEffects, totalRam, lowRamDevice)
        if (choice == GraphicsChoice.AUTO) return automatic
        val requested = GraphicsTier.valueOf(choice.name)
        val ceiling = if (heavyEffects) GraphicsTier.CINEMATIC else GraphicsTier.AMBIENT
        return if (requested.ordinal > ceiling.ordinal) ceiling else requested
    }

    fun label(tier: GraphicsTier) = when (tier) {
        GraphicsTier.STATIC -> "Static"
        GraphicsTier.AMBIENT -> "Ambient"
        GraphicsTier.CINEMATIC -> "Cinematic"
    }
}

/** Frame rate for a state under a quality budget; 0 = settle, then stop drawing. */
fun evaFps(state: EvaState, quality: EvaQuality): Int {
    val look = EvaLook.of(state).fps
    if (look == 0) return 0
    val resting = state == EvaState.IDLE || state == EvaState.OFFLINE
    return minOf(look, if (resting) quality.idleFps else quality.maxFps)
}
