package com.example.homeezch.ai

import org.junit.Assert.*
import org.junit.Test

class GlmConnectionTest {
    @Test fun remoteBrokersRequireHttpsAndCannotCarryCredentialsQueriesOrAlternatePaths() {
        assertTrue(GlmConnection.validEndpoint("https://eva.example.org"))
        assertTrue(GlmConnection.validEndpoint("http://127.0.0.1:8765"))
        for (url in listOf("http://192.168.1.10:8765", "http://example.org", "https://user:pass@example.org", "https://example.org/key?q=x", "https://example.org/#key", "file:///tmp/key", "https://example.org:70000"))
            assertFalse(url, GlmConnection.validEndpoint(url))
    }
    @Test fun cloudSpeechMustBeBoundedAndContainNoControlSequences() {
        assertTrue(GlmConversation.safeReply("Привет! Чем помочь?"))
        for (text in listOf("", " ", "x".repeat(1201), "answer\u0000")) assertFalse(GlmConversation.safeReply(text))
    }
}
